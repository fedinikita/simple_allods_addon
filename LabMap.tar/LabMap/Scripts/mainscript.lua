local l = common.LogInfo
local fws = userMods.FromWString
local tws = userMods.ToWString

local wtMainPanel = nil
local wtHeader = nil
local wtMap = nil
local wtMapContainer = nil
local wtMapPoint = nil
local wtAddMarker = nil
local wtButtonMapMenu = nil
local wtMapMenu = nil
local wtColorMenu = nil
local wtMarkerList = nil

-- маркеры
local wtCrownMarker = nil
local wtLockMarker = nil
local wtOrangeMobMarker = nil
local wtRedMobMarker = nil
local wtGreenMobMarker = nil
local wtBlueMobMarker = nil
local wtBulbMarker = nil
local wtRedCircleMarker = nil

local wtRedStarMarker = nil
local wtBlueStarMarker = nil
local wtGreenStarMarker = nil
local wtGiftMarker = nil
local wtInsightMarker = nil
local wtPotionMarker = nil
local wtQuestionMarker = nil
local wtRarityMarker = nil
local wtRuneMarker = nil
local wtServiceMarker = nil
-- маркеры

local wtHeaderButton = nil
local wtWhiteButton = nil
local wtBlackButton = nil
local wtRedButton = nil
local wtBlueButton = nil
local wtPlusButton = nil
local wtMinusButton = nil

local wtAvatarArrow = nil

-- диалог сохранения
local wtDialogSaveMap = nil
local wtDialogLoadMap = nil
local wtDialogSizeMap = nil
local wtDialogMarkersListMap = nil

local wtMapNameButton = nil
local wtMarkerNameButton = nil

local points = {}
local markers = {}
local offset = {}

local vpWidth = 0
local vpHeight = 0
local addonIsEnabled = false
local zoom = 1
local currentZoneName = nil

local currentColor = { r = 1.0, g = 1.0, b = 1.0, a = 1.0 }

local animSpeed = 250

local realpos = nil

function resize(widget, sizeX, sizeY, bIsAnim)
	bIsAnim = bIsAnim or 1
	local pp = widget:GetPlacementPlain()
	local pp2 = widget:GetPlacementPlain()
	pp2.sizeX = sizeX
	pp2.sizeY = sizeY
	if bIsAnim == 1 then
		widget:PlayResizeEffect(pp, pp2, animSpeed, EA_MONOTONOUS_INCREASE)
	else
		widget:SetPlacementPlain(pp2)
	end
end

function move(widget, posX, posY, bIsAnim)
	bIsAnim = bIsAnim or 1
	local pp = widget:GetPlacementPlain()
	local pp2 = widget:GetPlacementPlain()
	pp2.posX = posX
	pp2.posY = posY
	if bIsAnim == 1 then
		widget:PlayMoveEffect(pp, pp2, animSpeed, EA_MONOTONOUS_INCREASE)
	else
		widget:SetPlacementPlain(pp2)
	end
end

function animateFade(widget)
	widget:PlayFadeEffect(0.0, 1.0, 1500, EA_MONOTONOUS_INCREASE)
end

function OnEventAvatarCreated(params)
	common.RegisterEventHandler(OnEventAvatarPosChanged, "EVENT_AVATAR_POS_CHANGED")
	common.RegisterEventHandler(OnEventAvatarDirChanged, "EVENT_AVATAR_DIR_CHANGED")
	common.RegisterEventHandler(OnEventAvatarClientZoneChanged, "EVENT_AVATAR_CLIENT_ZONE_CHANGED")

	common.RegisterReactionHandler(OnReactionButtonShowMarkerListPressed, "ReactionButtonShowMarkerListPressed")
	common.RegisterReactionHandler(OnReactionButtonAddMarkerPressed, "ReactionButtonAddMarkerPressed")
	common.RegisterReactionHandler(OnReactionButtonShowColorMenuPressed, "ButtonShowColorMenuPressed")

	common.RegisterReactionHandler(OnReactionButtonShowMapMenuPressed, "ButtonShowMapMenuPressed")

	common.RegisterReactionHandler(OnReactionButtonMapSavePressed, "ButtonMapSavePressed")
	common.RegisterReactionHandler(OnReactionButtonMapLoadPressed, "ButtonMapLoadPressed")
	common.RegisterReactionHandler(OnReactionButtonMapSizePressed, "ButtonMapSizePressed")
	common.RegisterReactionHandler(OnReactionButtonMapMarkersListPressed, "ButtonMapMarkersListPressed")

	common.RegisterReactionHandler(OnReactionDialogLoadMapCloseButtonPressed, "DialogLoadMapCloseButtonPressed")
	common.RegisterReactionHandler(OnReactionDialogMarkersListMapCloseButtonPressed,
		"DialogMarkersListMapCloseButtonPressed")
	common.RegisterReactionHandler(OnReactionDialogSaveMapCloseButtonPressed, "DialogSaveMapCloseButtonPressed")
	common.RegisterReactionHandler(OnReactionDialogSizeMapCloseButtonPressed, "DialogSizeMapCloseButtonPressed")
	common.RegisterReactionHandler(OnReactionDialogSaveMapSaveButtonPressed, "DialogSaveMapSaveButtonPressed")

	common.RegisterReactionHandler(OnReactionMapNameButtonPressed, "MapNameButtonPressed")
	common.RegisterReactionHandler(OnReactionMapNameDeleteButtonPressed, "MapNameDeleteButtonPressed")

	common.RegisterReactionHandler(OnReactionMapMarkerDeleteButtonPressed, "MapMarkerDeleteButtonPressed")

	common.RegisterReactionHandler(OnReactionXSliderChanged, "xslider_changed")
	common.RegisterReactionHandler(OnReactionYSliderChanged, "yslider_changed")

	move(wtMapContainer, vpWidth / 2, vpHeight / 2, 0)

	OnEventAvatarPosChanged()
	wtAvatarArrow:Rotate(avatar.GetDir())

	local zoneInfo = cartographer.GetCurrentZoneInfo()
	if zoneInfo then
		currentZoneName = zoneInfo.zoneName
	end

	local cfg = userMods.GetGlobalConfigSection("LM_MapSize")
	if not cfg then
		cfg = {}
	end
	if not cfg.sizeX then
		cfg.sizeX = 0
	end
	if not cfg.sizeY then
		cfg.sizeY = 0
	end

	vpWidth = cfg.sizeX + 500
	vpHeight = cfg.sizeY + 500
	resize(wtMap, vpWidth, vpHeight, 0)
	wtDialogSizeMap:GetChildChecked("XSlider", false):SetPos(cfg.sizeX)
	wtDialogSizeMap:GetChildChecked("YSlider", false):SetPos(cfg.sizeY)
	OnEventAvatarPosChanged({})
end

function OnEventAvatarPosChanged()
	realpos = calcRealpos()
	addPoint(realpos.x5, realpos.y5)

	if addonIsEnabled then
		local px = (realpos.fx * zoom) - 16
		local py = (-realpos.fy * zoom) - 16
		wtAvatarArrow:FinishMoveEffect();
		move(wtAvatarArrow, px, py, 0)
		wtMapContainer:FinishMoveEffect();
		move(wtMapContainer, -(px - vpWidth / 2) - 16, -(py - vpHeight / 2) - 16, 0)
	end
end

function updateZoom()
	-- Точки
	for x, _ in pairs(points) do
		for y, _ in pairs(points[x]) do
			points[x][y]:FinishResizeEffect()
			points[x][y]:FinishMoveEffect()

			resize(points[x][y], 5 * zoom, 5 * zoom, 0)
			move(points[x][y], x * 5 * zoom, -y * 5 * zoom, 0)
		end
	end

	-- Маркеры
	for x, _ in pairs(markers) do
		for y, _ in pairs(markers[x]) do
			if zoom < 1 then
				resize(markers[x][y], 22 * zoom, 22 * zoom, 0)
				move(markers[x][y], x * zoom - 11 * zoom, -y * zoom - 11 * zoom, 0)
			else
				resize(markers[x][y], 22, 22, 0)
				move(markers[x][y], x * zoom - 11, -y * zoom - 11, 0)
			end
		end
	end

	OnEventAvatarPosChanged()
end

function OnEventAvatarDirChanged(params)
	if addonIsEnabled then
		wtAvatarArrow:Rotate(params.dir)
	end
end

-- показать список маркеров
function OnReactionButtonShowMarkerListPressed(params)
	wtMapMenu:Show(false)
	wtMarkerList:Show(not wtMarkerList:IsVisible())
	wtColorMenu:Show(false)
end

-- показать список цветов
function OnReactionButtonShowColorMenuPressed(params)
	wtMapMenu:Show(false)
	wtMarkerList:Show(false)
	wtColorMenu:Show(not wtColorMenu:IsVisible())
end

-- добавление маркеров
function OnReactionButtonAddMarkerPressed(params)
	--realpos = calcRealpos()
	local wgtName = params.widget:GetName()
	wtMarkerList:Show(false)

	local tbl = {}
	tbl["ButtonAddCrownMarker"] = wtCrownMarker
	tbl["ButtonAddLockMarker"] = wtLockMarker
	tbl["ButtonAddOrangeMobMarker"] = wtOrangeMobMarker
	tbl["ButtonAddBlueMobMarker"] = wtBlueMobMarker
	tbl["ButtonAddBulbMarker"] = wtBulbMarker
	tbl["ButtonAddRedCircleMarker"] = wtRedCircleMarker
	tbl["ButtonAddRedMobMarker"] = wtRedMobMarker
	tbl["ButtonAddGreenMobMarker"] = wtGreenMobMarker

	tbl["ButtonAddRedStarMarker"] = wtRedStarMarker
	tbl["ButtonAddBlueStarMarker"] = wtBlueStarMarker
	tbl["ButtonAddGreenStarMarker"] = wtGreenStarMarker
	tbl["ButtonAddGiftMarker"] = wtGiftMarker
	tbl["ButtonAddInsightMarker"] = wtInsightMarker
	tbl["ButtonAddPotionMarker"] = wtPotionMarker
	tbl["ButtonAddQuestionMarker"] = wtQuestionMarker
	tbl["ButtonAddRarityMarker"] = wtRarityMarker
	tbl["ButtonAddRuneMarker"] = wtRuneMarker
	tbl["ButtonAddServiceMarker"] = wtServiceMarker

	if tbl[wgtName] then
		addMarker(realpos.intx, realpos.inty, tbl[wgtName]:GetName())
	end
end

-- показать меню карты(загрузить/сохранить)
function OnReactionButtonShowMapMenuPressed(params)
	wtMapMenu:Show(not wtMapMenu:IsVisible())
	wtMarkerList:Show(false)
	wtColorMenu:Show(false)
end

--показываем диалог сохранения
function OnReactionButtonMapSavePressed(params)
	wtMapMenu:Show(false)

	local zoneMap = cartographer.GetCurrentZoneInfo()
	if zoneMap then
		local location = fws(zoneMap.allod) .. "_" .. fws(zoneMap.zoneName)
		if zoneMap.subZoneName then
			location = location .. "_" .. fws(zoneMap.subZoneName)
		end
		location = location:gsub(" ", "_")
		wtDialogSaveMap:GetChildChecked("NameMapEdit", false):SetText(tws(location))
	end

	wtDialogSaveMap:Show(true)
end

--показываем диалог загрузки
function OnReactionButtonMapLoadPressed(params)
	wtMapMenu:Show(false)
	wtDialogLoadMap:Show(true)

	local container = wtDialogLoadMap:GetChildChecked("MapsContainer", false)
	container:RemoveItems()

	local cfg = userMods.GetGlobalConfigSection("LM_maps")
	if cfg then
		local keys = {}

		for mapName, strMap in pairs(cfg) do
			table.insert(keys, mapName)
		end

		table.sort(keys, function(a, b) return a < b end)

		for i, mapName in pairs(keys) do
			local wgt = mainForm:CreateWidgetByDesc(wtMapNameButton:GetWidgetDesc())
			wgt:GetChildChecked("MapNameDeleteButton", false):GetChildChecked("MapNameDeleteText", false):SetVal("value",
				tws(GTL("Delete")))
			wgt:GetChildChecked("MapNameText", false):SetVal("value", mapName)
			container:PushBack(wgt)
			wgt:Show(true)
		end
	end
end

--показываем диалог изменения размеров карты
function OnReactionButtonMapSizePressed(params)
	wtMapMenu:Show(false)
	wtMap:SetBackgroundColor({ r = 0.0, g = 0.4, b = 0.0, a = 0.4 })
	wtDialogSizeMap:Show(true)
end

--показываем список маркеров для редактирования
function OnReactionButtonMapMarkersListPressed(params)
	wtMapMenu:Show(false)
	wtDialogMarkersListMap:Show(true)

	local container = wtDialogMarkersListMap:GetChildChecked("MapsContainer", false)
	container:RemoveItems()

	for x, _ in pairs(markers) do
		for y, _ in pairs(markers[x]) do
			local wgt = mainForm:CreateWidgetByDesc(wtMarkerNameButton:GetWidgetDesc())
			wgt:GetChildChecked("MapNameDeleteButton", false):GetChildChecked("MapNameDeleteText", false):SetVal("value",
				tws(GTL("Delete")))
			wgt:GetChildChecked("MapNameText", false):SetVal("value", markers[x][y]:GetName())
			--wgt:GetChildChecked("MarkerNameIcon",false):SetBackgroundTexture(markers[x][y]:GetBackgroundTexture())
			container:PushBack(wgt)
			wgt:Show(true)


			-- common.LogInfo("", markers[x][y]:GetWidgetDesc().BackLayer)
		end
	end
end

function OnReactionDialogSaveMapCloseButtonPressed(params)
	wtDialogSaveMap:Show(false)
end

function OnReactionDialogSizeMapCloseButtonPressed(params)
	wtMap:SetBackgroundColor({ r = 0.0, g = 0.0, b = 0.0, a = 0.0 })
	wtDialogSizeMap:Show(false)
end

function OnReactionXSliderChanged(params)
	local x = params.widget:GetPos()
	local pp = wtMap:GetPlacementPlain()
	pp.sizeX = x + 500
	wtMap:SetPlacementPlain(pp)
	vpWidth = x + 500
	OnEventAvatarPosChanged({})

	local cfg = userMods.GetGlobalConfigSection("LM_MapSize")
	if not cfg then
		cfg = {}
	end
	if not cfg.sizeY then
		cfg.sizeY = 500
	end
	cfg.sizeX = x

	userMods.SetGlobalConfigSection("LM_MapSize", cfg)
end

function OnReactionYSliderChanged(params)
	local y = params.widget:GetPos()
	local pp = wtMap:GetPlacementPlain()
	pp.sizeY = y + 500
	wtMap:SetPlacementPlain(pp)
	vpHeight = y + 500
	OnEventAvatarPosChanged({})

	local cfg = userMods.GetGlobalConfigSection("LM_MapSize")
	if not cfg then
		cfg = {}
	end
	if not cfg.sizeX then
		cfg.sizeX = 500
	end

	cfg.sizeY = y

	userMods.SetGlobalConfigSection("LM_MapSize", cfg)
end

-- нажали кнопку сохранить в диалоге сохранения
function OnReactionDialogSaveMapSaveButtonPressed(params)
	local cfg = userMods.GetGlobalConfigSection("LM_maps")
	if not cfg then
		cfg = {}
	end

	local mapName = fws(wtDialogSaveMap:GetChildChecked("NameMapEdit", false):GetText()):gsub(" ", "_")
	local mapTable = mapSaveToTable()

	cfg[mapName] = mapTable
	userMods.SetGlobalConfigSection("LM_maps", cfg)
	wtDialogSaveMap:Show(false)
end

function OnReactionDialogLoadMapCloseButtonPressed(params)
	wtDialogLoadMap:Show(false)
end

function OnReactionDialogMarkersListMapCloseButtonPressed(params)
	wtDialogMarkersListMap:Show(false)
end

-- нажали кнопку загрузить в диалоге загрузки карты
function OnReactionMapNameButtonPressed(params)
	wtDialogLoadMap:Show(false)
	local mapName = fws(params.widget:GetChildChecked("MapNameText", false):GetValuedText():ToWString())
	local cfg = userMods.GetGlobalConfigSection("LM_maps")
	if cfg then
		if cfg[mapName] then
			mapLoadFromTable(cfg[mapName])
		end
	end
end

-- удаляем карту
function OnReactionMapNameDeleteButtonPressed(params)
	local mapName = fws(params.widget:GetParent():GetChildChecked("MapNameText", false):GetValuedText():ToWString())

	local cfg = userMods.GetGlobalConfigSection("LM_maps")
	if cfg then
		if cfg[mapName] then
			cfg[mapName] = nil
			userMods.SetGlobalConfigSection("LM_maps", cfg)
			OnReactionButtonMapLoadPressed({})
		end
	end
end

function OnReactionMapMarkerDeleteButtonPressed(params)
	local markerName = fws(params.widget:GetParent():GetChildChecked("MapNameText",
		false):GetValuedText():ToWString())

	for x, _ in pairs(markers) do
		for y, _ in pairs(markers[x]) do
			if markers[x][y]:GetName() == markerName then
				wtMapContainer:GetChildChecked(markers[x][y]:GetName(), false):DestroyWidget()
				markers[x][y] = nil
			end
			-- local wgt = mainForm:CreateWidgetByDesc(wtMarkerNameButton:GetWidgetDesc())
			-- wgt:GetChildChecked("MapNameDeleteButton",false):GetChildChecked("MapNameDeleteText",false):SetVal("value",tws(GTL("Delete")))
			-- wgt:GetChildChecked("MapNameText",false):SetVal("value", markers[x][y]:GetName())
			-- --wgt:GetChildChecked("MarkerNameIcon",false):SetBackgroundTexture(markers[x][y]:GetBackgroundTexture())
			-- container:PushBack(wgt)
			-- wgt:Show(true)


			-- common.LogInfo("", markers[x][y]:GetWidgetDesc().BackLayer)
		end
	end
	OnReactionButtonMapMarkersListPressed({})
end

function addPoint(x, y)
	if not points[x] then
		points[x] = {}
	end
	if not points[x][y] then
		local mapPoint = mainForm:CreateWidgetByDesc(wtMapPoint:GetWidgetDesc())
		points[x][y] = mapPoint
		local p = mapPoint:GetPlacementPlain()
		p.posX = x * 5 * zoom
		p.posY = -y * 5 * zoom
		p.sizeX = 5 * zoom
		p.sizeY = 5 * zoom
		mapPoint:SetPlacementPlain(p)
		mapPoint:SetBackgroundColor(currentColor)
		wtMapContainer:AddChild(mapPoint)
		animateFade(mapPoint)
	end
end

function addMarker(x, y, markerType)
	if not markers[x] then
		markers[x] = {}
	end

	if markers[x][y] then return end

	local t = {}
	t["LockMarker"] = wtLockMarker
	t["CrownMarker"] = wtCrownMarker
	t["OrangeMobMarker"] = wtOrangeMobMarker
	t["BlueMobMarker"] = wtBlueMobMarker
	t["BulbMarker"] = wtBulbMarker
	t["RedCircleMarker"] = wtRedCircleMarker
	t["RedMobMarker"] = wtRedMobMarker
	t["GreenMobMarker"] = wtGreenMobMarker

	t["RedStarMarker"] = wtRedStarMarker
	t["GreenStarMarker"] = wtGreenStarMarker
	t["BlueStarMarker"] = wtBlueStarMarker
	t["GiftMarker"] = wtGiftMarker
	t["InsightMarker"] = wtInsightMarker
	t["PotionMarker"] = wtPotionMarker
	t["QuestionMarker"] = wtQuestionMarker
	t["RarityMarker"] = wtRarityMarker
	t["RuneMarker"] = wtRuneMarker
	t["ServiceMarker"] = wtServiceMarker

	local mt = t[markerType]
	local m = mainForm:CreateWidgetByDesc(mt:GetWidgetDesc())
	m:SetName(markerType);
	move(m, x * zoom - 11, -y * zoom - 11, 0)
	if zoom < 1 then
		resize(m, 22 * zoom, 22 * zoom, 0)
	else
		resize(m, 22, 22, 0)
	end
	wtMapContainer:AddChild(m)
	animateFade(m)

	markers[x][y] = m
end

function OnEventAvatarClientZoneChanged()
	reset()
end

function reset()
	for x, _ in pairs(points) do
		for y, _ in pairs(points[x]) do
			points[x][y]:DestroyWidget()
		end
	end
	points = {}

	for x, _ in pairs(markers) do
		for y, _ in pairs(markers[x]) do
			markers[x][y]:DestroyWidget()
		end
	end
	markers = {}

	wtAvatarArrow:Rotate(avatar.GetDir())
	OnEventAvatarPosChanged()
end

function enableAddon()
	local pp = wtHeader:GetPlacementPlain()
	pp.alignX = ENUM_AlignX_CENTER
	wtHeader:SetPlacementPlain(pp)
	wtHeader:SetClipContent(false)
	wtMainPanel:SetClipContent(false)

	resize(wtMainPanel, 500, 500, 0)

	wtAvatarArrow:Rotate(avatar.GetDir())
	local realpos = calcRealpos()
	local px = realpos.intx * zoom - 16
	local py = -realpos.inty * zoom - 16
	move(wtAvatarArrow, px, py, 0)
	move(wtMapContainer, -(px - vpWidth / 2) - 16, -(py - vpHeight / 2) - 16, 0)
end

function disableAddon()
	local pp = wtHeader:GetPlacementPlain()
	pp.alignX = ENUM_AlignX_RIGHT
	wtHeader:SetPlacementPlain(pp)
	resize(wtMainPanel, 105, 32, 0)
	wtHeader:SetClipContent(true)
	wtMainPanel:SetClipContent(true)
end

-- скрыть/показать главное акно аддона
function OnReactionHeaderButtonPressed(params)
	addonIsEnabled = not addonIsEnabled
	if addonIsEnabled then
		enableAddon()
	else
		disableAddon()
	end
end

-- выбрать цвет карты
function OnReactionColorButtonPressed(params)
	currentColor = params.widget:GetBackgroundColor()
	wtColorMenu:Show(false)
	updateColors(currentColor)
end

function updateColors(color)
	for x, _ in pairs(points) do
		for y, _ in pairs(points[x]) do
			points[x][y]:SetBackgroundColor(color)
		end
	end
end

-- масштаб
function OnReactionZoomButtonPressed(params)
	local name = params.widget:GetName()
	if name == "PlusButton" then
		zoom = zoom + 0.2
		if zoom > 2 then
			zoom = 2
		end
	elseif name == "MinusButton" then
		zoom = zoom - 0.2
		if zoom < 0.4 then
			zoom = 0.4
		end
	end

	updateZoom()
end

function calcRealpos()
	local realpos = {}

	local pos = avatar.GetPos()
	local _

	realpos.fx = pos.posX
	realpos.fy = pos.posY
	realpos.fz = pos.posZ

	realpos.intx, _ = math.modf(pos.posX)
	realpos.inty, _ = math.modf(pos.posY)
	realpos.intz, _ = math.modf(pos.posZ)

	realpos.x5 = (realpos.intx - (realpos.intx) % 5) / 5
	realpos.y5 = (realpos.inty - (realpos.inty) % 5) / 5
	realpos.z5 = (realpos.intz - (realpos.intz) % 5) / 5

	return realpos
end

function mapSave()
	local t = {}

	table.insert(t, "points")
	for x, _ in pairs(points) do
		for y, _ in pairs(points[x]) do
			table.insert(t, x .. "," .. y)
		end
	end

	table.insert(t, "markers")
	for x, _ in pairs(markers) do
		for y, _ in pairs(markers[x]) do
			table.insert(t, x .. "," .. y .. "," .. markers[x][y]:GetName())
		end
	end

	return table.concat(t, ";")
end

function mapLoad(strmap)
	function split(s, delimiter)
		local result = {}
		for match in (s .. delimiter):gmatch("(.-)" .. delimiter) do
			table.insert(result, match)
		end
		return result
	end

	local arr = split(strmap, ";")
	local currentSection = ""
	for _, line in pairs(arr) do
		if line == "points" or line == "markers" then
			currentSection = line
		else
			local coords = split(line, ",")
			if currentSection == "points" then
				local x = tonumber(coords[1])
				local y = tonumber(coords[2])
				addPoint(x, y)
			elseif
				currentSection == "markers" then
				local x = tonumber(coords[1])
				local y = tonumber(coords[2])
				local markerType = coords[3]
				addMarker(x, y, markerType)
			end
		end
	end

	local realpos = calcRealpos()
	local px = realpos.intx * zoom - 16
	local py = -realpos.inty * zoom - 16
	move(wtAvatarArrow, px, py, 0)
	move(wtMapContainer, -(px - vpWidth / 2) - 16, -(py - vpHeight / 2) - 16, 0)
end

function mapSaveToTable()
	local t = {}

	t.points = {}
	for x, _ in pairs(points) do
		for y, _ in pairs(points[x]) do
			table.insert(t.points, { x = x, y = y })
		end
	end

	t.markers = {}
	for x, _ in pairs(markers) do
		for y, _ in pairs(markers[x]) do
			table.insert(t.markers, { x = x, y = y, name = markers[x][y]:GetName() })
		end
	end

	return t
end

function mapLoadFromTable(mapTable)
	for k, v in pairs(mapTable.points) do
		addPoint(v.x, v.y)
	end

	for k, v in pairs(mapTable.markers) do
		addMarker(v.x, v.y, v.name)
	end

	local realpos = calcRealpos()
	local px = realpos.intx * zoom - 16
	local py = -realpos.inty * zoom - 16
	move(wtAvatarArrow, px, py, 0)
	move(wtMapContainer, -(px - vpWidth / 2) - 16, -(py - vpHeight / 2) - 16, 0)
end

function Init()
	wtMainPanel = mainForm:GetChildChecked("LabMap", false)

	wtMarkerList = wtMainPanel:GetChildChecked("MarkerList", false)

	wtMapMenu = wtMainPanel:GetChildChecked("MapMenu", false)
	wtColorMenu = wtMainPanel:GetChildChecked("ColorMenu", false)

	wtRedMobMarker = wtMainPanel:GetChildChecked("RedMobMarker", false)
	wtGreenMobMarker = wtMainPanel:GetChildChecked("GreenMobMarker", false)
	wtOrangeMobMarker = wtMainPanel:GetChildChecked("OrangeMobMarker", false)
	wtLockMarker = wtMainPanel:GetChildChecked("LockMarker", false)
	wtCrownMarker = wtMainPanel:GetChildChecked("CrownMarker", false)
	wtBlueMobMarker = wtMainPanel:GetChildChecked("BlueMobMarker", false)
	wtBulbMarker = wtMainPanel:GetChildChecked("BulbMarker", false)
	wtRedCircleMarker = wtMainPanel:GetChildChecked("RedCircleMarker", false)

	wtRedStarMarker = wtMainPanel:GetChildChecked("RedStarMarker", false)
	wtGreenStarMarker = wtMainPanel:GetChildChecked("GreenStarMarker", false)
	wtBlueStarMarker = wtMainPanel:GetChildChecked("BlueStarMarker", false)
	wtGiftMarker = wtMainPanel:GetChildChecked("GiftMarker", false)
	wtInsightMarker = wtMainPanel:GetChildChecked("InsightMarker", false)
	wtPotionMarker = wtMainPanel:GetChildChecked("PotionMarker", false)
	wtQuestionMarker = wtMainPanel:GetChildChecked("QuestionMarker", false)
	wtRarityMarker = wtMainPanel:GetChildChecked("RarityMarker", false)
	wtRuneMarker = wtMainPanel:GetChildChecked("RuneMarker", false)
	wtServiceMarker = wtMainPanel:GetChildChecked("ServiceMarker", false)


	wtMapPoint = wtMainPanel:GetChildChecked("MapPoint", false)

	wtMap = wtMainPanel:GetChildChecked("Map", false)
	wtMap:SetBackgroundColor({ r = 0.0, g = 1.0, b = 0.0, a = 0.0 })

	wtMapContainer = wtMap:GetChildChecked("MapContainer", false)
	wtMapContainer:SetBackgroundColor({ r = 1.0, g = 0.0, b = 0.0, a = 0.0 })

	wtHeader = wtMainPanel:GetChildChecked("Header", false)

	wtHeaderButton = wtHeader:GetChildChecked("HeaderButton", false)

	wtAddMarker = wtHeader:GetChildChecked("ButtonAddMarker", false)
	wtButtonMapMenu = wtHeader:GetChildChecked("ButtonMapMenu", false)

	wtWhiteButton = wtColorMenu:GetChildChecked("WhiteButton", false)
	wtWhiteButton:SetBackgroundColor({ r = 1.0, g = 1.0, b = 1.0, a = 1.0 })
	wtBlackButton = wtColorMenu:GetChildChecked("BlackButton", false)
	wtBlackButton:SetBackgroundColor({ r = 0.0, g = 0.0, b = 0.0, a = 1.0 })
	wtRedButton = wtColorMenu:GetChildChecked("RedButton", false)
	wtRedButton:SetBackgroundColor({ r = 1.0, g = 0.0, b = 0.0, a = 1.0 })
	wtBlueButton = wtColorMenu:GetChildChecked("BlueButton", false)
	wtBlueButton:SetBackgroundColor({ r = 0.0, g = 0.0, b = 1.0, a = 1.0 })

	wtPlusButton = wtHeader:GetChildChecked("PlusButton", false)
	wtMinusButton = wtHeader:GetChildChecked("MinusButton", false)

	wtDialogSaveMap = mainForm:GetChildChecked("DialogSaveMap", false)
	wtDialogLoadMap = mainForm:GetChildChecked("DialogLoadMap", false)
	wtDialogSizeMap = mainForm:GetChildChecked("DialogSizeMap", false)
	wtDialogMarkersListMap = mainForm:GetChildChecked("DialogMarkersListMap", false)

	wtMapNameButton = wtDialogLoadMap:GetChildChecked("MapNameButton", false)
	wtMarkerNameButton = wtDialogMarkersListMap:GetChildChecked("MarkerNameButton", false)

	-- Localization
	wtHeader:GetChildChecked("ButtonColorMenu", false):GetChildChecked("ButtonColorMenuText", false):SetVal("value",
		tws(GTL("Color")))

	wtButtonMapMenu:GetChildChecked("ButtonMapMenuText", false):SetVal("value", tws(GTL("Map")))
	wtMapMenu:GetChildChecked("ButtonMapSave", false):GetChildChecked("ButtonMapMenuSaveText", false):SetVal("value",
		tws(GTL("Save")))
	wtMapMenu:GetChildChecked("ButtonMapLoad", false):GetChildChecked("ButtonMapMenuLoadText", false):SetVal("value",
		tws(GTL("Load")))
	wtMapMenu:GetChildChecked("ButtonMapSize", false):GetChildChecked("ButtonMapMenuSizeText", false):SetVal("value",
		tws(GTL("Size")))
	wtMapMenu:GetChildChecked("ButtonMapMarkersList", false):GetChildChecked("ButtonMapMarkersListText", false):SetVal(
		"value", tws(GTL("Marker List")))

	wtDialogSaveMap:GetChildChecked("DialogSaveMapHeader", false):GetChildChecked("DialogSaveMapHeaderText", false)
		:SetVal("value", tws(GTL("Save Map")))
	wtDialogSaveMap:GetChildChecked("DialogSaveMapSaveButton", false):GetChildChecked("MapSaveButtonText", false):SetVal(
		"value", tws(GTL("Save")))

	wtDialogLoadMap:GetChildChecked("DialogLoadMapHeader", false):GetChildChecked("DialogLoadMapHeaderText", false)
		:SetVal("value", tws(GTL("Load Map")))
	wtMapNameButton:GetChildChecked("MapNameDeleteButton", false):GetChildChecked("MapNameDeleteText", false):SetVal(
		"value", tws(GTL("Delete")))

	wtDialogSizeMap:GetChildChecked("DialogSizeMapHeader", false):GetChildChecked("DialogSizeMapHeaderText", false)
		:SetVal("value", tws(GTL("Map Size")))
	wtDialogSizeMap:GetChildChecked("XText", false):SetVal("value", tws(GTL("Width")))
	wtDialogSizeMap:GetChildChecked("YText", false):SetVal("value", tws(GTL("Height")))

	wtHeader:GetChildChecked("ButtonAddMarker", false):GetChildChecked("ButtonAddMarkerText", false):SetVal("value",
		tws(GTL("Marker")))


	local mapPlacement = wtMap:GetPlacementPlain()
	vpWidth = mapPlacement.sizeX
	vpHeight = mapPlacement.sizeY

	wtAvatarArrow = wtMainPanel:GetChildChecked("AvatarArrow", false)

	wtMapContainer:AddChild(wtAvatarArrow)

	common.RegisterReactionHandler(OnReactionHeaderButtonPressed, "ReactionHeaderButtonPressed")
	common.RegisterReactionHandler(OnReactionColorButtonPressed, "ReactionColorButtonPressed")
	common.RegisterReactionHandler(OnReactionZoomButtonPressed, "ReactionZoomButtonPressed")

	DnD.Init(wtMainPanel, wtHeader, true)
	DnD.Init(wtMainPanel, wtHeaderButton, true)
	DnD.Init(wtDialogSaveMap, wtDialogSaveMap:GetChildChecked("DialogSaveMapHeader", false), true)
	DnD.Init(wtDialogLoadMap, wtDialogLoadMap:GetChildChecked("DialogLoadMapHeader", false), true)
	DnD.Init(wtDialogSizeMap, wtDialogSizeMap:GetChildChecked("DialogSizeMapHeader", false), true)
	DnD.Init(wtDialogMarkersListMap, wtDialogMarkersListMap:GetChildChecked("DialogLoadMapHeader", false), true)

	if avatar.IsExist() then
		OnEventAvatarCreated({})
	else
		common.RegisterEventHandler(OnEventAvatarCreated, "EVENT_AVATAR_CREATED")
	end

	if addonIsEnabled then
		enableAddon()
	else
		disableAddon()
	end

	resize(wtMapContainer, 1, 1, 0)
end

Init()
